## ---- include = FALSE---------------------------------------------------------
library(knitr)
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>", 
  fig.width = 5, fig.asp = 1, cache = FALSE,
  cache.extra = rand_seed # attempt to cache random seed for reproduction 
)

## ----setup, echo = FALSE------------------------------------------------------
options(digits = 4, scipen = 1)
library(remoteSTAR) # load the package

## ----random seed--------------------------------------------------------------
set.seed(58) # set the random seed for this document

## ----data setup, echo = FALSE, eval = FALSE-----------------------------------
#  ## Full data ----
#  # read in the data
#  ndvi <- data.table::fread(file = "../data-raw/north_america_checked.csv")
#  
#  # convert $land column to a factor
#  land.classes = c("Evergr needle","Evergr broad","Decid needle","Decid broad",
#                   "Mixed forest","Shrubland","Savanna","Grassland","Cropland",
#                   "Cropland mosaics") # all land classes (in order of lvs)
#  
#  ndvi$land <- factor(ndvi$land, labels = land.classes)
#  
#  # save the rdata file
#  if(!file.exists("../data/ndvi.rda")){
#    save(ndvi, file =  "../data/ndvi.rda", compress = "xz")
#  }
#  
#  ## Alaska subset ----
#  ndvi_AK <- ndvi[ndvi$lng < -141, ] #North Am. west of -141 is approx. AK
#  ndvi_AK$land <- droplevels(ndvi_AK$land)
#  
#  # relative contirbution of each land class to AK
#  tmp <- aggregate(
#    x = ndvi_AK$land,
#    by = list(landclass = ndvi_AK$land),
#    FUN = function(x)length(x)/nrow(ndvi_AK)
#  )
#  
#  # any land class that occurs less than 2% is rare
#  ndvi_AK$rare.land <- tmp[match(ndvi_AK$land, tmp$landclass), "x"] <= 0.02
#  
#  # reorder columns so ndvi are all at the end
#  ord <- c(grep("ndvi", names(ndvi_AK), invert = TRUE), #columns without 'ndvi'
#           grep("ndvi", names(ndvi_AK))) # cols with ndvi
#  ndvi_AK <- ndvi_AK[, ..ord] #..x is data.table notation
#  
#  # save AK data file
#  if(!file.exists("../data/ndvi_AK.rda")){
#    save(ndvi_AK, file = "../data/ndvi_AK.rda", compress = "xz")
#  }
#  
#  ## subset AK further
#  ndvi_AK3000 <- ndvi_AK[!ndvi_AK$rare.land, ] # only common land classes
#  ndvi_AK3000 <- ndvi_AK3000[sample.int(n = nrow(ndvi_AK3000), size = 3000), ] # 3000 pts
#  
#  # save small AK data file
#  if(!file.exists("../data/ndvi_AK3000.rda")){
#    save(ndvi_AK3000, file = "../data/ndvi_AK3000.rda", compress = "xz")
#  }

## ----ndvi_AK3000 data---------------------------------------------------------
# load the dataset
data("ndvi_AK3000")

# extract some useful info
X <- as.matrix(ndvi_AK3000[, -c(1:6)]) # columns containing NDVI measurements
n = nrow(X); p = ncol(X) # dimensions of X
location = ndvi_AK3000[, c("lng", "lat")] # geographic location of each site
time.int = 1:p # time points as standard integers
time.scaled = scale(time.int) # scaled and centered time

## ----cls_star AK3000----------------------------------------------------------
# perform time series analysis for each site (no intercept)
fm.cls <- cls_star(X, t = time.scaled) # can be slow

rel.est <- with(fm.cls, Est/mean) # relative estimate

## ----print cls_star output----------------------------------------------------
head(fm.cls)

## ----plot AK3000 outl map-----------------------------------------------------
# index of possible outliers
outl <- abs(scale(rel.est)) > -qnorm(p = 1/n/10) # criteria

## Make a plot to visualize where outliers are
# define color of points low NDVI = orange, high NDVI = green
base.col = ifelse(test = outl, yes = "black",
                  no = colorRampPalette(
                    c("darkgoldenrod3", "grey70", "chartreuse3")
                    )(nrow(fm.cls))[ordered(rel.est)]
)

# make legend labels from rel.est summary stats
labels <- round(c(max = max(rel.est), # boundaries of color changes
                  mid = median(rel.est), 
                  min = min(rel.est)), 2)
labels <- c(labels, outl = "outlier") # outliers

# build the plot
plot(y = ndvi_AK3000$lat, x = ndvi_AK3000$lng, pch = 15, cex = .5, 
     col = base.col,
     xlab = "longitude", ylab = "latitude")
legend(x = "bottomright", fill = c("chartreuse3", "grey70",
                                   "darkgoldenrod", "black"),
       legend = labels, title = "NDVI change")

## ----outl hist----------------------------------------------------------------
## value of outliers relative to overall distribution
hist(fm.cls$mean[outl], freq = FALSE, breaks = 0:20, ylim = c(0,.5), col = "grey",
     lty = 3, xlab = "site average NDVI", main = "Histogram of NDVI")
hist(fm.cls$mean[!outl], freq = FALSE, breaks = 0:20, ylim = c(0,.5), col = NULL,
     add = TRUE)
legend("topright", legend = c("TRUE","FALSE"), fill = c("grey", "white"),
       title = "outlier")

## ----fit_spatialcor-----------------------------------------------------------
# calculate distance matrix (km) to use later
D = geosphere::distm(location)/1000
meth = "exponential-power" # transformation method

# estimate spatial correlation
(r.est <- fit_spatialcor(X, time.scaled, location = location, 
                         fun = meth)) #calculates D internally

## ----fitV---------------------------------------------------------------------
## Fit variance matrix
V <- fitV(D, spatialcor = r.est$spatialcor, fun = meth)

## -----------------------------------------------------------------------------
# get the inverse of the chol decomp of V (can be time consuming)
tInvCholV <- tinvchol_cpp(V, nugget = 0)

## get model matrix from formulae
# full model
form = "rel.est ~ 0 + land" 
mod.mat <- model.matrix(object = formula(form), data = ndvi_AK3000)
# null model
form0 = "rel.est ~ 1"
X0 <- model.matrix(object = formula(form0), data = ndvi_AK3000)

## estimate maximum likelihood nugget
tolr = .00001 # precision of nugget search
nugget.ml <- optimizeNugget_cpp(X = mod.mat, V = V, y = rel.est,
                                lower = 0, upper = 1, tol = tolr)

## fit GLS 
fm.gls <- fitGLS_cpp(X = mod.mat, V = V, y = rel.est, X0 = X0,
                     nugget = nugget.ml)

## ----GLS t_pvalues------------------------------------------------------------
# add in pvalues (this will eventually be done with classes internally)
fm.gls$pval.t <- sapply(fm.gls$tstat, function(x){
  2 * pt(abs(x), df = fm.gls$dft, lower.tail = F)
})
# feature names
names(fm.gls$pval.t) <- names(fm.gls$betahat) <- gsub(x = colnames(mod.mat),
                                                      pattern = "land", 
                                                      replacement = "")

# print p-values
cbind("pt" = fm.gls$pval.t) # fail to reject H0 for all land classes

## -----------------------------------------------------------------------------
  # F-test
fm.gls$pval.F <- pf(fm.gls$Fstat, df1 = fm.gls$df.F[1], df2 = fm.gls$df.F[2], 
                    lower.tail = FALSE)

# ## print the coefficients
# round(fm.gls$betahat, 4)

# F-test ## H0: no change in NDVI over time for all of AK3000
round(cbind("F" = fm.gls$Fstat, "pval" = fm.gls$pval.F), 4) # fail to reject H0

## ----partitioned GLS----------------------------------------------------------
## run the parittioned analysis
results.cpp <- fitGLS.partition_rcpp(X = mod.mat, y = rel.est, X0 = X0, Dist = D,
                                 spatcor = r.est$spatialcor, Vfit.fun = meth,
                                 npart = 5, mincross = 4, nug.int = c(0, 1),
                                 nug.tol = tolr, workerB_cpp = TRUE)

## -----------------------------------------------------------------------------
# F tests for each partition
t(sapply(results.cpp$part_results, function(x){c("F" = round(x$Fstat, 4), 
                                           "pval" = round(x$pval.F, 4))}))

## -----------------------------------------------------------------------------
# Cross-partition F test
pval.Fpart <- GLS.partition.pvalue(results.cpp, nboot = 2000)

round(cbind("Fmean" = results.cpp$Fmean, "pval" = pval.Fpart$pF.boot$pvalue), 4)

## ---- eval = FALSE, echo = FALSE----------------------------------------------
#  data("ndvi_AK")
#  ndvi_AK <- ndvi_AK[!ndvi_AK$rare.land, ]
#  ndvi_AK$land <- droplevels(ndvi_AK$land)
#  
#  ## 4 different subsets
#  subs <- matrix(sample.int(n = nrow(ndvi_AK), size = 3000 * 4, replace = FALSE),
#                 nrow = 3000)
#  
#  ## Apply the test to 4 different subsets of 3000 AK sites
#  Ftest_sub <- sapply(1:ncol(subs), function(i){
#    ss = sample.int(n = nrow(ndvi_AK), size = 3000, replace = FALSE)
#    AKsub <- ndvi_AK[ss, ]
#    loc_i <- AKsub[, c("lng", "lat")]
#    Xsub <-  as.matrix(AKsub[, 7:38])
#    sc_i <- fit_spatialcor(X = Xsub, t = time.scaled,
#                           location = loc_i, fun = meth)$spatialcor
#    D_i <- geosphere::distm(loc_i)/1000
#    fm.cls_i <- cls_star(Xsub, t = time.scaled)
#    y_i <- with(fm.cls_i, Est/mean)
#    fm_i <- fitGLS.partition_rcpp(X = Xsub, y = y_i, X0 = X0, Dist = D_i,
#                                  spatcor = sc_i, Vfit.fun = meth, npart = 5,
#                                  mincross = 4, workerB_cpp = TRUE)
#    F_i <- fm_i$Fmean
#    p_i <- GLS.partition.pvalue(fm_i, nboot = 2000)$pF.boot$pvalue
#  
#    return(c("F" = F_i, "pval" = p_i))
#  })
#  
#  print(Ftest_sub)
#  
#  rm("ndvi_AK")

## ----GLS_partition, eval = FALSE, echo = FALSE--------------------------------
#  n.p = 50; n.part = 3
#  partition <- matrix(sample(1:nrow(ndvi_AK3000), size = n.p * n.part), ncol = n.part)
#  x.1 = as.vector(partition[, 1])
#  x.2 = as.vector(partition[, 2])
#  x.12 = c(x.1, x.2)
#  ## For now, I'm going to explore the distributed computing option
#  
#  ### partition 1
#  y1 <- rnorm(n.p)
#  X1 <- as.matrix(ndvi_AK3000[x.1, -c(1:6)])
#  loc1 <- ndvi_AK3000[x.1, c("lat","lng")]
#  V1 <- fitV(D[x.1, x.1],
#              spatialcor = r.est$spatialcor, fun = "exponential-power")
#  
#  ### partition 2
#  y2 <- rnorm(n.p)
#  X2 <- as.matrix(ndvi_AK3000[x.2, -c(1:6)])
#  loc2 <- ndvi_AK3000[x.2, c("lat","lng")]
#  V2 <- fitV(D[x.2, x.2],
#              spatialcor = r.est$spatialcor, fun = "exponential-power")
#  
#  ## cross partition
#  V12 <- fitV(D[x.12, x.12],
#               spatialcor = r.est$spatialcor, fun = "exponential-power")
#  Vsub <- V12[1:n.p, (n.p+1):(2*n.p)]
#  
#  Xnull <- matrix(1, nrow = nrow(X1))
#  
#  df2 <- n.p - (ncol(X1) - 1)
#  df0 <- n.p - (ncol(Xnull) - 1)
#  df1 <- df0 - df2

## ---- eval = FALSE, echo = FALSE----------------------------------------------
#  ## results
#  out1 <- GLS_worker_cpp(y1, X1, V1, Xnull, save_xx = TRUE)
#  out2 <- GLS_worker_cpp(y2, X2, V2, Xnull, save_xx = TRUE)
#  
#  ## The cross-partition step is where it breaks down
#  ## last worked when n.p was 400 but no larger
#  out.cross.cpp <- crosspart_worker_cpp(xxi = out1$xx, xxj = out2$xx,
#                                    xxi0 = out1$xx0, xxj0 = out2$xx0,
#                                    tUinv_i = out1$tInvCholV,
#                                    tUinv_j = out2$tInvCholV,
#                                    Vsub = Vsub,
#                                    df1 = df1, df2 = df2) # not working yet
#  
#  out.cross <- crosspart_worker(xxi = out1$xx, xxj = out2$xx,
#                                    xxi0 = out1$xx0, xxj0 = out2$xx0,
#                                    tUinv_i = out1$tInvCholV,
#                                    tUinv_j = out2$tInvCholV,
#                                    Vsub = Vsub,
#                                    df1 = df1, df2 = df2) # not working yet
#  
#  ## test that the 2 versions give the same output
#  for(i in 1:length(out.cross)){
#    print(names(out.cross)[i])
#    print(all.equal(out.cross[[i]], out.cross.cpp[[i]]))
#  }
#  
#  

## ---- eval = FALSE, echo = FALSE----------------------------------------------
#  size.Mb <- function(x){format(object.size(x), units = "Kb")}
#  sizes <- data.frame(obj = c("out1", "out2", "outcross"),
#                      MB = c(size.Mb(out1), size.Mb(out2), size.Mb(out.cross))
#                      )
#  sizes
#  
#  ## could it be a memory issue? MB is the size of out.cross with different n.p values
#  curve = data.frame(n.p = c(100, 80, 60), MB = c(3.5, 2.2, 1.2))
#  fm <- lm(curve$MB ~ curve$n.p)
#  plot(curve$MB ~ curve$n.p); abline(fm)
#  pred <- function(np){(np * coef(fm)[2]) + coef(fm)[1]}
#  pred(c(150, 300, 600))

