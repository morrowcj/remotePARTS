#' @keywords internal
"_PACKAGE"

#' @import Rcpp
#' @importFrom Rcpp evalCpp
## usethis namespace: start
#' @useDynLib remoteSTAR, .registration = TRUE
## usethis namespace: end
NULL
