## ---- include = FALSE---------------------------------------------------------
library(knitr)
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>", 
  fig.width = 5, fig.asp = 1,
  cache.extra = rand_seed # attempt to cache random seed for reproduction 
)

## ----setup--------------------------------------------------------------------
library(remoteSTAR)

## ----random seed--------------------------------------------------------------
set.seed(58) # set the random seed for this document

## ----data setup, echo = FALSE, eval = FALSE-----------------------------------
#  ## Full data ----
#  # read in the data
#  ndvi <- data.table::fread(file = "../data-raw/north_america_checked.csv")
#  
#  # convert $land column to a factor
#  land.classes = c("Evergr needle","Evergr broad","Decid needle","Decid broad",
#                   "Mixed forest","Shrubland","Savanna","Grassland","Cropland",
#                   "Cropland mosaics") # all land classes (in order of lvs)
#  
#  ndvi$land <- factor(ndvi$land, labels = land.classes)
#  
#  # save the rdata file
#  if(!file.exists("../data/ndvi.RData")){
#    save(ndvi, file =  "../data/ndvi.RData")
#  }
#  
#  ## Alaska subset ----
#  ndvi_AK <- ndvi[ndvi$lng < -141, ] #North Am. west of -141 is approx. AK
#  
#  # relative contirbution of each land class to AK
#  tmp <- aggregate(
#    x = ndvi_AK$land,
#    by = list(landclass = ndvi_AK$land),
#    FUN = function(x)length(x)/nrow(ndvi_AK)
#  )
#  
#  # any land class that occurs less than 2% is rare
#  ndvi_AK$rare.land <- tmp[match(ndvi_AK$land, tmp$landclass), "x"] <= 0.02
#  
#  # reorder columns so ndvi are all at the end
#  ord <- c(grep("ndvi", names(ndvi_AK), invert = TRUE), #columns without 'ndvi'
#           grep("ndvi", names(ndvi_AK))) # cols with ndvi
#  ndvi_AK <- ndvi_AK[, ..ord] #..x is data.table notation
#  
#  # save AK data file
#  if(!file.exists("../data/ndvi_AK.RData")){
#    save(ndvi_AK, file = "../data/ndvi_AK.RData")
#  }
#  
#  ## subset AK further
#  ndvi_AK3000 <- ndvi_AK[!ndvi_AK$rare.land, ] # only common land classes
#  ndvi_AK3000 <- ndvi_AK3000[sample.int(n = nrow(ndvi_AK3000), size = 3000), ] # 3000 pts
#  
#  # save small AK data file
#  if(!file.exists("../data/ndvi_AK3000.RData")){
#    save(ndvi_AK3000, file = "../data/ndvi_AK3000.RData")
#  }

## ----ndvi_AK3000 data---------------------------------------------------------
# load the dataset
data("ndvi_AK3000")

# remove rare land classes
ndvi_AK3000 <- ndvi_AK3000[!ndvi_AK3000$rare.land, ]
if(FALSE){ ## make data set very small to test that things work quickly
  ndvi_AK3000 <- ndvi_AK3000[1:500, ]
}
# extract some info
X <- as.matrix(ndvi_AK3000[, -c(1:6)]) # columns containing NDVI measurements
n = nrow(X); p = ncol(X) # dimensions of X
location = ndvi_AK3000[, c("lng", "lat")] # geographic location of each site
time.int = 1:p # time points as standard integers

## ----cls_star AK3000----------------------------------------------------------
# perform time series analysis for each site (no intercept)
fm.cls <- cls_star(X, t = time.int) # can be slow
rel.est <- with(fm.cls, (Est/(1 - x_t0.EST))/mean) # relative estimate

knitr::kable(head(fm.cls), digits = 4) # show results

## ----plot AK3000 outl map-----------------------------------------------------
# index of outliers
outl <- abs(scale(rel.est)) > -qnorm(p = 1/n/10)

# define color of points low NDVI = orange, high NDVI = green
base.col = ifelse(test = outl, yes = "black",
                  no = colorRampPalette(
                    c("orange", "grey", "darkgreen")
                    )(nrow(fm.cls))[ordered(rel.est)]
)
maximum <- round(max(rel.est), 2)
median <- round(median(rel.est), 2)
minimum <- round(min(rel.est), 2)

plot(ndvi_AK3000$lat ~ ndvi_AK3000$lng, pch = 15, cex = .5, col = base.col,
     xlab = "longitude", ylab = "latitude")
legend(x = "bottomright", fill = c("darkgreen", "grey","orange", "black"),
       legend = c(maximum, median, minimum, "outlier"), title = "NDVI change")

## -----------------------------------------------------------------------------
## value of outliers relative to overall distribution
hist(fm.cls$mean[outl], freq = FALSE, breaks = 0:20, ylim = c(0,.5), col = "grey",
     lty = 3, xlab = "site average NDVI", main = "Histogram of NDVI")
hist(fm.cls$mean[!outl], freq = FALSE, breaks = 0:20, ylim = c(0,.5), col = NULL,
     add = TRUE)
legend("topright", legend = c("TRUE","FALSE"), fill = c("grey", "white"),
       title = "outlier")

## ----fit_spatialcor-----------------------------------------------------------
# calculate distance matrix (km)
D = geosphere::distm(location)/1000
meth = "exponential-power" # transformation method

# estimate spatial correlation
(r.est <- fit_spatialcor(X, time.int, location = location, 
                         fun = meth)) #calculates D internally

## ----GLS----------------------------------------------------------------------
## Fit variance matrix
V <- fitV(D, spatialcor = r.est$spatialcor, fun = meth)

## inverse of the chol decomp of V (time consuming)
tInvCholV <- tinvchol_cpp(V, nugget = 0)

mod.mat <- cbind("Intercept" = 1, X) # add an intercept
X0 <- matrix(rep(1, n), ncol = 1) # null model matrix
tolr = .00001


## estimate maximum likelihood nugget
nugget.ml <- optimizeNugget_cpp(X = mod.mat, V = V, y = rel.est,
                                lower = 0, upper = 1, tol = tolr)

## fit GLS 
fm.gls <- fitGLS_cpp(X = mod.mat, V = V, y = rel.est, X0 = X0,
                     nugget = nugget.ml)

## add in pvalues (this will eventually be done with classes)
  # t-test
fm.gls$pval.t <- sapply(fm.gls$tstat, function(x){
  2 * pt(abs(x), df = fm.gls$dft, lower.tail = F)
})
names(fm.gls$pval.t) <- colnames(mod.mat)
  # F-test
fm.gls$pval.F <- pf(fm.gls$Fstat, df1 = fm.gls$df.F[1], df2 = fm.gls$df.F[2], 
                    lower.tail = FALSE)

## print p-values
# t-test ## H0: No difference in NDVI among sites at given time
round(fm.gls$pval.t, 4) 

# F-test ## H0: no change in NDVI over time for all of AK3000
round(fm.gls$pval.F, 4) # reject H0

## ----partitioned GLS----------------------------------------------------------
results <- fitGLS.partition_rcpp(X = X, y = rel.est, X0 = X0, Dist = D,
                                 spatcor = r.est$spatialcor, Vfit.fun = meth,
                                 npart = 5, mincross = 4, nug.int = c(0, 1),
                                 nug.tol = tolr)

# ## t tests for each partition
# lapply(results$part_results, function(x)rbind("t" = round(x$tstat, 4),
#                                               "pval" = round(x$pval.t, 4)))

library(dplyr)

## F tests for each partition
lapply(results$part_results, function(x){c("F" = round(x$Fstat, 4), 
                                           "pval" = round(x$pval.F, 4))}) %>% 
  bind_rows()

## Cross-partition F test
pval.Fpart <- GLS.partition.pvalue(results, nboot = 2000)
c("F" = results$Fmean, "pval" = pval.Fpart[1])

## ----GLS_partition, eval = FALSE, echo = FALSE--------------------------------
#  n.p = 50; n.part = 3
#  partition <- matrix(sample(1:nrow(ndvi_AK3000), size = n.p * n.part), ncol = n.part)
#  ix.1 = as.vector(partition[, 1])
#  ix.2 = as.vector(partition[, 2])
#  ix.12 = c(ix.1, ix.2)
#  ## For now, I'm going to explore the distributed computing option
#  
#  ### partition 1
#  y1 <- rnorm(n.p)
#  X1 <- as.matrix(ndvi_AK3000[ix.1, -c(1:6)])
#  loc1 <- ndvi_AK3000[ix.1, c("lat","lng")]
#  V1 <- fitV(D[ix.1, ix.1],
#              spatialcor = r.est$spatialcor, fun = "exponential-power")
#  
#  ### partition 2
#  y2 <- rnorm(n.p)
#  X2 <- as.matrix(ndvi_AK3000[ix.2, -c(1:6)])
#  loc2 <- ndvi_AK3000[ix.2, c("lat","lng")]
#  V2 <- fitV(D[ix.2, ix.2],
#              spatialcor = r.est$spatialcor, fun = "exponential-power")
#  
#  ## cross partition
#  V12 <- fitV(D[ix.12, ix.12],
#               spatialcor = r.est$spatialcor, fun = "exponential-power")
#  Vsub <- V12[1:n.p, (n.p+1):(2*n.p)]
#  
#  Xnull <- matrix(1, nrow = nrow(X1))
#  
#  df2 <- n.p - (ncol(X1) - 1)
#  df0 <- n.p - (ncol(Xnull) - 1)
#  df1 <- df0 - df2

## ---- eval = FALSE, echo = FALSE----------------------------------------------
#  ## results
#  out1 <- GLS_worker_cpp(y1, X1, V1, Xnull, save_xx = TRUE)
#  out2 <- GLS_worker_cpp(y2, X2, V2, Xnull, save_xx = TRUE)
#  
#  ## The cross-partition step is where it breaks down
#  ## last worked when n.p was 400 but no larger
#  out.cross.cpp <- crosspart_worker_cpp(xxi = out1$xx, xxj = out2$xx,
#                                    xxi0 = out1$xx0, xxj0 = out2$xx0,
#                                    tUinv_i = out1$tInvCholV,
#                                    tUinv_j = out2$tInvCholV,
#                                    Vsub = Vsub,
#                                    df1 = df1, df2 = df2) # not working yet
#  
#  out.cross <- crosspart_worker(xxi = out1$xx, xxj = out2$xx,
#                                    xxi0 = out1$xx0, xxj0 = out2$xx0,
#                                    tUinv_i = out1$tInvCholV,
#                                    tUinv_j = out2$tInvCholV,
#                                    Vij = V12,
#                                    df1 = df1, df2 = df2) # not working yet

## ---- eval = FALSE, echo = FALSE----------------------------------------------
#  size.Mb <- function(x){format(object.size(x), units = "Kb")}
#  sizes <- data.frame(obj = c("out1", "out2", "outcross"),
#                      MB = c(size.Mb(out1), size.Mb(out2), size.Mb(out.cross))
#                      )
#  sizes
#  
#  ## could it be a memory issue? MB is the size of out.cross with different n.p values
#  curve = data.frame(n.p = c(100, 80, 60), MB = c(3.5, 2.2, 1.2))
#  fm <- lm(curve$MB ~ curve$n.p)
#  plot(curve$MB ~ curve$n.p); abline(fm)
#  pred <- function(np){(np * coef(fm)[2]) + coef(fm)[1]}
#  pred(c(150, 300, 600))

