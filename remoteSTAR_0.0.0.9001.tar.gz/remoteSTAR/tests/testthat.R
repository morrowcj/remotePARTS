library(testthat)
library(remoteSTAR)

# test_check("remoteSTAR")
